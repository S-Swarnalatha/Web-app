from django.shortcuts import render
from .models import Hero


def getPostsList(request):
    postList = Hero.objects.all()
    context ={
        "postList" : postList
    }
    return render(request, template_name='post/food.html', context=context)


def getHome(request):
    cohort = {
        "current_cohort": "21.2",
        "cohort_name": "Romans"
    }

    return render(request, template_name='post/home.html', context=cohort)
